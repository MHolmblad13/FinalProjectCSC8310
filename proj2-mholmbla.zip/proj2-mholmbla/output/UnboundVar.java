public class UnboundVar extends EvalError {
    UnboundVar() { super(); }
    UnboundVar(String s) { super(s); }
}
