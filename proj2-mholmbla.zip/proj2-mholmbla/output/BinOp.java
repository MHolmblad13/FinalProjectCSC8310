public enum BinOp {
    PLUS {public String toString() {return "+";}},
    MINUS {public String toString() {return "-";}},
    TIMES {public String toString() {return "*";}},
    DIV {public String toString() {return "/";}},
    EQ {public String toString() {return "=";}},   
    LT {public String toString() {return "<";}},
    AND {public String toString() {return "&";}},
    OR {public String toString() {return "|";}}
}
