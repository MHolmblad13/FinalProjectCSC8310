public class EvalError extends Exception {
    EvalError() { super(); }
    EvalError(String s) { super(s); }
}
