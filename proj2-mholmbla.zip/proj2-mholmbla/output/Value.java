public abstract class Value {
    abstract public String toString();
}
